
// Função para alternar o tema
function toggleTheme() {
    const body = document.body;
    const themeButton = document.getElementById('toggle-theme');

    // Verifica se o tema atual é escuro
    if (body.classList.contains('dark-theme')) {
        // Remove a classe de tema escuro
        body.classList.remove('dark-theme');
        // Atualiza o texto do botão
        themeButton.style = "background-image: url('data:image/svg+xml;base64,PCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KDTwhLS0gVXBsb2FkZWQgdG86IFNWRyBSZXBvLCB3d3cuc3ZncmVwby5jb20sIFRyYW5zZm9ybWVkIGJ5OiBTVkcgUmVwbyBNaXhlciBUb29scyAtLT4KPHN2ZyB3aWR0aD0iODAwcHgiIGhlaWdodD0iODAwcHgiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KDTxnIGlkPSJTVkdSZXBvX2JnQ2FycmllciIgc3Ryb2tlLXdpZHRoPSIwIi8+Cg08ZyBpZD0iU1ZHUmVwb190cmFjZXJDYXJyaWVyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KDTxnIGlkPSJTVkdSZXBvX2ljb25DYXJyaWVyIj4gPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMS4wMTc0IDIuODAxNTdDNi4zNzA3MiAzLjI5MjIxIDIuNzUgNy4yMjMyOCAyLjc1IDEyQzIuNzUgMTcuMTA4NiA2Ljg5MTM3IDIxLjI1IDEyIDIxLjI1QzE2Ljc3NjcgMjEuMjUgMjAuNzA3OCAxNy42MjkzIDIxLjE5ODQgMTIuOTgyNkMxOS44NzE3IDE0LjY2NjkgMTcuODEyNiAxNS43NSAxNS41IDE1Ljc1QzExLjQ5NTkgMTUuNzUgOC4yNSAxMi41MDQxIDguMjUgOC41QzguMjUgNi4xODczOCA5LjMzMzE1IDQuMTI4MyAxMS4wMTc0IDIuODAxNTdaTTEuMjUgMTJDMS4yNSA2LjA2Mjk0IDYuMDYyOTQgMS4yNSAxMiAxLjI1QzEyLjcxNjYgMS4yNSAxMy4wNzU0IDEuODIxMjYgMTMuMTM2OCAyLjI3NjI3QzEzLjE5NiAyLjcxMzk4IDEzLjAzNDIgMy4yNzA2NSAxMi41MzEgMy41NzQ2N0MxMC44NjI3IDQuNTgyOCA5Ljc1IDYuNDExODIgOS43NSA4LjVDOS43NSAxMS42NzU2IDEyLjMyNDQgMTQuMjUgMTUuNSAxNC4yNUMxNy41ODgyIDE0LjI1IDE5LjQxNzIgMTMuMTM3MyAyMC40MjUzIDExLjQ2OUMyMC43MjkzIDEwLjk2NTggMjEuMjg2IDEwLjgwNCAyMS43MjM3IDEwLjg2MzJDMjIuMTc4NyAxMC45MjQ2IDIyLjc1IDExLjI4MzQgMjIuNzUgMTJDMjIuNzUgMTcuOTM3MSAxNy45MzcxIDIyLjc1IDEyIDIyLjc1QzYuMDYyOTQgMjIuNzUgMS4yNSAxNy45MzcxIDEuMjUgMTJaIiBmaWxsPSIjNTQ2NTZmIi8+IDwvZz4KDTwvc3ZnPg==')";
        // Salva a preferência no localStorage
        localStorage.setItem('theme', 'light');
    } else {
        // Adiciona a classe de tema escuro
        body.classList.add('dark-theme');
        // Atualiza o texto do botão
        themeButton.style = "background-image: url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48IS0tIFVwbG9hZGVkIHRvOiBTVkcgUmVwbywgd3d3LnN2Z3JlcG8uY29tLCBHZW5lcmF0b3I6IFNWRyBSZXBvIE1peGVyIFRvb2xzIC0tPg0KPHN2ZyB3aWR0aD0iODAwcHgiIGhlaWdodD0iODAwcHgiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTIgMS4yNUMxMi40MTQyIDEuMjUgMTIuNzUgMS41ODU3OSAxMi43NSAyVjRDMTIuNzUgNC40MTQyMSAxMi40MTQyIDQuNzUgMTIgNC43NUMxMS41ODU4IDQuNzUgMTEuMjUgNC40MTQyMSAxMS4yNSA0VjJDMTEuMjUgMS41ODU3OSAxMS41ODU4IDEuMjUgMTIgMS4yNVpNMy42Njg2NSAzLjcxNjA5QzMuOTQ4MTUgMy40MTAzOSA0LjQyMjU1IDMuMzg5MTUgNC43MjgyNSAzLjY2ODY1TDYuOTUwMjYgNS43MDAyNEM3LjI1NTk2IDUuOTc5NzQgNy4yNzcyIDYuNDU0MTMgNi45OTc3IDYuNzU5ODNDNi43MTgyIDcuMDY1NTMgNi4yNDM4IDcuMDg2NzcgNS45MzgxIDYuODA3MjdMMy43MTYwOSA0Ljc3NTY5QzMuNDEwMzkgNC40OTYxOSAzLjM4OTE1IDQuMDIxNzkgMy42Njg2NSAzLjcxNjA5Wk0yMC4zMzE0IDMuNzE2MDlDMjAuNjEwOSA0LjAyMTc5IDIwLjU4OTYgNC40OTYxOSAyMC4yODM5IDQuNzc1NjlMMTguMDYxOSA2LjgwNzI3QzE3Ljc1NjIgNy4wODY3NyAxNy4yODE4IDcuMDY1NTMgMTcuMDAyMyA2Ljc1OTgzQzE2LjcyMjggNi40NTQxMyAxNi43NDQgNS45Nzk3NCAxNy4wNDk3IDUuNzAwMjRMMTkuMjcxOCAzLjY2ODY1QzE5LjU3NzUgMy4zODkxNSAyMC4wNTE4IDMuNDEwMzkgMjAuMzMxNCAzLjcxNjA5Wk0xMiA3Ljc1QzkuNjUyNzkgNy43NSA3Ljc1IDkuNjUyNzkgNy43NSAxMkM3Ljc1IDE0LjM0NzIgOS42NTI3OSAxNi4yNSAxMiAxNi4yNUMxNC4zNDcyIDE2LjI1IDE2LjI1IDE0LjM0NzIgMTYuMjUgMTJDMTYuMjUgOS42NTI3OSAxNC4zNDcyIDcuNzUgMTIgNy43NVpNNi4yNSAxMkM2LjI1IDguODI0MzYgOC44MjQzNiA2LjI1IDEyIDYuMjVDMTUuMTc1NiA2LjI1IDE3Ljc1IDguODI0MzYgMTcuNzUgMTJDMTcuNzUgMTUuMTc1NiAxNS4xNzU2IDE3Ljc1IDEyIDE3Ljc1QzguODI0MzYgMTcuNzUgNi4yNSAxNS4xNzU2IDYuMjUgMTJaTTEuMjUgMTJDMS4yNSAxMS41ODU4IDEuNTg1NzkgMTEuMjUgMiAxMS4yNUg0QzQuNDE0MjEgMTEuMjUgNC43NSAxMS41ODU4IDQuNzUgMTJDNC43NSAxMi40MTQyIDQuNDE0MjEgMTIuNzUgNCAxMi43NUgyQzEuNTg1NzkgMTIuNzUgMS4yNSAxMi40MTQyIDEuMjUgMTJaTTE5LjI1IDEyQzE5LjI1IDExLjU4NTggMTkuNTg1OCAxMS4yNSAyMCAxMS4yNUgyMkMyMi40MTQyIDExLjI1IDIyLjc1IDExLjU4NTggMjIuNzUgMTJDMjIuNzUgMTIuNDE0MiAyMi40MTQyIDEyLjc1IDIyIDEyLjc1SDIwQzE5LjU4NTggMTIuNzUgMTkuMjUgMTIuNDE0MiAxOS4yNSAxMlpNMTcuMDI1NSAxNy4wMjUyQzE3LjMxODQgMTYuNzMyMyAxNy43OTMzIDE2LjczMjMgMTguMDg2MiAxNy4wMjUyTDIwLjMwODIgMTkuMjQ3NUMyMC42MDExIDE5LjU0MDQgMjAuNjAxIDIwLjAxNTMgMjAuMzA4MSAyMC4zMDgyQzIwLjAxNTIgMjAuNjAxMSAxOS41NDAzIDIwLjYwMSAxOS4yNDc1IDIwLjMwODFMMTcuMDI1NSAxOC4wODU4QzE2LjczMjYgMTcuNzkyOSAxNi43MzI2IDE3LjMxODEgMTcuMDI1NSAxNy4wMjUyWk02Ljk3NDY3IDE3LjAyNTNDNy4yNjc1NiAxNy4zMTgyIDcuMjY3NTYgMTcuNzkzMSA2Ljk3NDY3IDE4LjA4Nkw0Ljc1MjQ0IDIwLjMwODJDNC40NTk1NSAyMC42MDExIDMuOTg0NjggMjAuNjAxMSAzLjY5MTc4IDIwLjMwODJDMy4zOTg4OSAyMC4wMTUzIDMuMzk4ODkgMTkuNTQwNCAzLjY5MTc4IDE5LjI0NzZMNS45MTQwMSAxNy4wMjUzQzYuMjA2OSAxNi43MzI0IDYuNjgxNzcgMTYuNzMyNCA2Ljk3NDY3IDE3LjAyNTNaTTEyIDE5LjI1QzEyLjQxNDIgMTkuMjUgMTIuNzUgMTkuNTg1OCAxMi43NSAyMFYyMkMxMi43NSAyMi40MTQyIDEyLjQxNDIgMjIuNzUgMTIgMjIuNzVDMTEuNTg1OCAyMi43NSAxMS4yNSAyMi40MTQyIDExLjI1IDIyVjIwQzExLjI1IDE5LjU4NTggMTEuNTg1OCAxOS4yNSAxMiAxOS4yNVoiIGZpbGw9IiNBRUJBQzEiLz4NCjwvc3ZnPg==');";
        // Salva a preferência no localStorage
        localStorage.setItem('theme', 'dark');
    }
}

// Função para aplicar o tema salvo no localStorage ao carregar a página
function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeButton = document.getElementById('toggle-theme');

    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        themeButton.style = "background-image: url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48IS0tIFVwbG9hZGVkIHRvOiBTVkcgUmVwbywgd3d3LnN2Z3JlcG8uY29tLCBHZW5lcmF0b3I6IFNWRyBSZXBvIE1peGVyIFRvb2xzIC0tPg0KPHN2ZyB3aWR0aD0iODAwcHgiIGhlaWdodD0iODAwcHgiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTIgMS4yNUMxMi40MTQyIDEuMjUgMTIuNzUgMS41ODU3OSAxMi43NSAyVjRDMTIuNzUgNC40MTQyMSAxMi40MTQyIDQuNzUgMTIgNC43NUMxMS41ODU4IDQuNzUgMTEuMjUgNC40MTQyMSAxMS4yNSA0VjJDMTEuMjUgMS41ODU3OSAxMS41ODU4IDEuMjUgMTIgMS4yNVpNMy42Njg2NSAzLjcxNjA5QzMuOTQ4MTUgMy40MTAzOSA0LjQyMjU1IDMuMzg5MTUgNC43MjgyNSAzLjY2ODY1TDYuOTUwMjYgNS43MDAyNEM3LjI1NTk2IDUuOTc5NzQgNy4yNzcyIDYuNDU0MTMgNi45OTc3IDYuNzU5ODNDNi43MTgyIDcuMDY1NTMgNi4yNDM4IDcuMDg2NzcgNS45MzgxIDYuODA3MjdMMy43MTYwOSA0Ljc3NTY5QzMuNDEwMzkgNC40OTYxOSAzLjM4OTE1IDQuMDIxNzkgMy42Njg2NSAzLjcxNjA5Wk0yMC4zMzE0IDMuNzE2MDlDMjAuNjEwOSA0LjAyMTc5IDIwLjU4OTYgNC40OTYxOSAyMC4yODM5IDQuNzc1NjlMMTguMDYxOSA2LjgwNzI3QzE3Ljc1NjIgNy4wODY3NyAxNy4yODE4IDcuMDY1NTMgMTcuMDAyMyA2Ljc1OTgzQzE2LjcyMjggNi40NTQxMyAxNi43NDQgNS45Nzk3NCAxNy4wNDk3IDUuNzAwMjRMMTkuMjcxOCAzLjY2ODY1QzE5LjU3NzUgMy4zODkxNSAyMC4wNTE4IDMuNDEwMzkgMjAuMzMxNCAzLjcxNjA5Wk0xMiA3Ljc1QzkuNjUyNzkgNy43NSA3Ljc1IDkuNjUyNzkgNy43NSAxMkM3Ljc1IDE0LjM0NzIgOS42NTI3OSAxNi4yNSAxMiAxNi4yNUMxNC4zNDcyIDE2LjI1IDE2LjI1IDE0LjM0NzIgMTYuMjUgMTJDMTYuMjUgOS42NTI3OSAxNC4zNDcyIDcuNzUgMTIgNy43NVpNNi4yNSAxMkM2LjI1IDguODI0MzYgOC44MjQzNiA2LjI1IDEyIDYuMjVDMTUuMTc1NiA2LjI1IDE3Ljc1IDguODI0MzYgMTcuNzUgMTJDMTcuNzUgMTUuMTc1NiAxNS4xNzU2IDE3Ljc1IDEyIDE3Ljc1QzguODI0MzYgMTcuNzUgNi4yNSAxNS4xNzU2IDYuMjUgMTJaTTEuMjUgMTJDMS4yNSAxMS41ODU4IDEuNTg1NzkgMTEuMjUgMiAxMS4yNUg0QzQuNDE0MjEgMTEuMjUgNC43NSAxMS41ODU4IDQuNzUgMTJDNC43NSAxMi40MTQyIDQuNDE0MjEgMTIuNzUgNCAxMi43NUgyQzEuNTg1NzkgMTIuNzUgMS4yNSAxMi40MTQyIDEuMjUgMTJaTTE5LjI1IDEyQzE5LjI1IDExLjU4NTggMTkuNTg1OCAxMS4yNSAyMCAxMS4yNUgyMkMyMi40MTQyIDExLjI1IDIyLjc1IDExLjU4NTggMjIuNzUgMTJDMjIuNzUgMTIuNDE0MiAyMi40MTQyIDEyLjc1IDIyIDEyLjc1SDIwQzE5LjU4NTggMTIuNzUgMTkuMjUgMTIuNDE0MiAxOS4yNSAxMlpNMTcuMDI1NSAxNy4wMjUyQzE3LjMxODQgMTYuNzMyMyAxNy43OTMzIDE2LjczMjMgMTguMDg2MiAxNy4wMjUyTDIwLjMwODIgMTkuMjQ3NUMyMC42MDExIDE5LjU0MDQgMjAuNjAxIDIwLjAxNTMgMjAuMzA4MSAyMC4zMDgyQzIwLjAxNTIgMjAuNjAxMSAxOS41NDAzIDIwLjYwMSAxOS4yNDc1IDIwLjMwODFMMTcuMDI1NSAxOC4wODU4QzE2LjczMjYgMTcuNzkyOSAxNi43MzI2IDE3LjMxODEgMTcuMDI1NSAxNy4wMjUyWk02Ljk3NDY3IDE3LjAyNTNDNy4yNjc1NiAxNy4zMTgyIDcuMjY3NTYgMTcuNzkzMSA2Ljk3NDY3IDE4LjA4Nkw0Ljc1MjQ0IDIwLjMwODJDNC40NTk1NSAyMC42MDExIDMuOTg0NjggMjAuNjAxMSAzLjY5MTc4IDIwLjMwODJDMy4zOTg4OSAyMC4wMTUzIDMuMzk4ODkgMTkuNTQwNCAzLjY5MTc4IDE5LjI0NzZMNS45MTQwMSAxNy4wMjUzQzYuMjA2OSAxNi43MzI0IDYuNjgxNzcgMTYuNzMyNCA2Ljk3NDY3IDE3LjAyNTNaTTEyIDE5LjI1QzEyLjQxNDIgMTkuMjUgMTIuNzUgMTkuNTg1OCAxMi43NSAyMFYyMkMxMi43NSAyMi40MTQyIDEyLjQxNDIgMjIuNzUgMTIgMjIuNzVDMTEuNTg1OCAyMi43NSAxMS4yNSAyMi40MTQyIDExLjI1IDIyVjIwQzExLjI1IDE5LjU4NTggMTEuNTg1OCAxOS4yNSAxMiAxOS4yNVoiIGZpbGw9IiNBRUJBQzEiLz4NCjwvc3ZnPg==');";
    } else {
        body.classList.remove('dark-theme');
        themeButton.style = 'background-image: url("data:image/svg+xml;base64,PCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KDTwhLS0gVXBsb2FkZWQgdG86IFNWRyBSZXBvLCB3d3cuc3ZncmVwby5jb20sIFRyYW5zZm9ybWVkIGJ5OiBTVkcgUmVwbyBNaXhlciBUb29scyAtLT4KPHN2ZyB3aWR0aD0iODAwcHgiIGhlaWdodD0iODAwcHgiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KDTxnIGlkPSJTVkdSZXBvX2JnQ2FycmllciIgc3Ryb2tlLXdpZHRoPSIwIi8+Cg08ZyBpZD0iU1ZHUmVwb190cmFjZXJDYXJyaWVyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KDTxnIGlkPSJTVkdSZXBvX2ljb25DYXJyaWVyIj4gPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMS4wMTc0IDIuODAxNTdDNi4zNzA3MiAzLjI5MjIxIDIuNzUgNy4yMjMyOCAyLjc1IDEyQzIuNzUgMTcuMTA4NiA2Ljg5MTM3IDIxLjI1IDEyIDIxLjI1QzE2Ljc3NjcgMjEuMjUgMjAuNzA3OCAxNy42MjkzIDIxLjE5ODQgMTIuOTgyNkMxOS44NzE3IDE0LjY2NjkgMTcuODEyNiAxNS43NSAxNS41IDE1Ljc1QzExLjQ5NTkgMTUuNzUgOC4yNSAxMi41MDQxIDguMjUgOC41QzguMjUgNi4xODczOCA5LjMzMzE1IDQuMTI4MyAxMS4wMTc0IDIuODAxNTdaTTEuMjUgMTJDMS4yNSA2LjA2Mjk0IDYuMDYyOTQgMS4yNSAxMiAxLjI1QzEyLjcxNjYgMS4yNSAxMy4wNzU0IDEuODIxMjYgMTMuMTM2OCAyLjI3NjI3QzEzLjE5NiAyLjcxMzk4IDEzLjAzNDIgMy4yNzA2NSAxMi41MzEgMy41NzQ2N0MxMC44NjI3IDQuNTgyOCA5Ljc1IDYuNDExODIgOS43NSA4LjVDOS43NSAxMS42NzU2IDEyLjMyNDQgMTQuMjUgMTUuNSAxNC4yNUMxNy41ODgyIDE0LjI1IDE5LjQxNzIgMTMuMTM3MyAyMC40MjUzIDExLjQ2OUMyMC43MjkzIDEwLjk2NTggMjEuMjg2IDEwLjgwNCAyMS43MjM3IDEwLjg2MzJDMjIuMTc4NyAxMC45MjQ2IDIyLjc1IDExLjI4MzQgMjIuNzUgMTJDMjIuNzUgMTcuOTM3MSAxNy45MzcxIDIyLjc1IDEyIDIyLjc1QzYuMDYyOTQgMjIuNzUgMS4yNSAxNy45MzcxIDEuMjUgMTJaIiBmaWxsPSIjNTQ2NTZmIi8+IDwvZz4KDTwvc3ZnPg==");';
    }
}

// Aplica o tema salvo quando a página é carregada
window.onload = applySavedTheme();

const textarea = document.getElementById("textoFinal");


function autoResize() {
    textarea.style.height = "auto"; // Reseta a altura para recalcular
    textarea.style.height = `${textarea.scrollHeight}px`; // Define a altura com base no conteúdo
}

window.onbeforeunload = function () {
    // Impede que o cache mantenha o estado dos campos
    window.location.reload(true);
};
window.onload = atualizarListaResumos();
function salvarResumo() {
    let tipoResumo = document.getElementById('tipoResumo').value;
    let idResumo = document.getElementById('idResumo').value.trim(); // Remove espaços em branco

    // Verifica se o ID do resumo está vazio
    if (idResumo === "") {
        alert("O campo ID do resumo é obrigatório!");
        return; // Interrompe a execução se o ID estiver vazio
    }

    let produtos = [];

    for (let i = 1; i <= contador; i++) {
        if (document.getElementById(`produto_${i}`)) {
            let produto = {
                valorUnitario: parseFloat(document.getElementById(`valorUnitario_${i}`).value) || 0,
                quantidade: parseFloat(document.getElementById(`quantidade_${i}`).value) || 1,
                multiplicar: document.getElementById(`multiplicar_${i}`).checked,
                designacaoUnitaria: document.getElementById(`designacaoUnitaria_${i}`).value || '',
                subquantidade: parseFloat(document.getElementById(`subquantidade_${i}`).value) || '',
                designacaoSub: document.getElementById(`designacaoSub_${i}`).value || '',
                nomeProduto: document.getElementById(`nomeProduto_${i}`).value || '',
                observacao: document.getElementById(`obsCheckbox_${i}`).checked ? document.getElementById(`observacao_${i}`).value : ''
            };
            produtos.push(produto);
        }
    }

    let desconto = {
        valor: parseFloat(document.getElementById('valorDesconto').value) || 0,
        tipo: document.getElementById('tipoDesconto').value,
        descontoPorQuantidade: document.getElementById('descQuant').checked
    };

    let taxaEntrega = {
        valor: parseFloat(document.getElementById('valorTaxa').value) || 0,
        tipo: document.getElementById('tipoTaxa').value,
        modalidade: document.getElementById('modalidade').value,
        outraModalidade: document.getElementById('outraModalidade').value,
        prazoInicial: document.getElementById('prazoEntrInicial').value,
        prazoFinal: document.getElementById('prazoEntrFinal').value
    };

    let resumo = {
        dataCriacao: new Date().toISOString(), // Armazena data e hora completas
        tipo: tipoResumo,
        id: idResumo,
        produtos: produtos,
        desconto: desconto,
        taxaEntrega: taxaEntrega
    };

    localStorage.setItem(`resumo_${idResumo}`, JSON.stringify(resumo));
    atualizarListaResumos();
    const button = document.getElementById("salvarResumo");
    button.textContent = "Salvo com Sucesso ✔";

    // Restaura o texto original após 2 segundos
    setTimeout(() => {
        button.textContent = "Salvar";
    }, 2000);
}

function atualizarListaResumos() {
    const listaResumos = document.getElementById('listaResumos');
    listaResumos.innerHTML = ''; // Limpa a lista antes de atualizar

    let resumos = [];

    for (let i = 0; i < localStorage.length; i++) {
        let chave = localStorage.key(i);
        if (chave.startsWith('resumo_')) {
            let resumo = JSON.parse(localStorage.getItem(chave));
            resumos.push(resumo); // Adiciona o resumo ao array
        }
    }

    // Ordena os resumos do mais recente para o mais antigo
    resumos.sort((a, b) => new Date(b.dataCriacao) - new Date(a.dataCriacao));

    // Exibe os resumos ordenados
    resumos.forEach(resumo => {
        let li = document.createElement('li');
        li.innerHTML = `${new Date(resumo.dataCriacao).toLocaleString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            year: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false
        })} ${resumo.tipo} ${resumo.id}`; // Exibe a data formatada
        li.onclick = () => carregarResumo(resumo.id);
        // Botão para carregar o resumo
        let btnCarregar = document.createElement('button');
        btnCarregar.textContent = "Abrir";
        btnCarregar.onclick = () => carregarResumo(resumo.id);
        btnCarregar.classList.add('oculto');
        // Botão para excluir o resumo
        let btnExcluir = document.createElement('button');
        btnExcluir.textContent = "✖";
        btnExcluir.onclick = () => excluirResumo(resumo.id);

        li.appendChild(btnCarregar);
        li.appendChild(btnExcluir);
        listaResumos.appendChild(li);
    });
}

function carregarResumo(id) {
    let resumo = JSON.parse(localStorage.getItem(`resumo_${id}`));

    if (resumo) {
        document.getElementById('tipoResumo').value = resumo.tipo;
        document.getElementById('idResumo').value = resumo.id;
        document.getElementById('titulo-section').innerText = `${resumo.tipo}: ${resumo.id}`;

        // Limpar produtos existentes
        while (contador > 1) {
            removerProduto(contador--);
        }

        // Adicionar os produtos do resumo
        resumo.produtos.forEach((produto, index) => {
            if (index > 0) adicionarProduto(); // Adiciona novos produtos se necessário

            document.getElementById(`valorUnitario_${index + 1}`).value = produto.valorUnitario;
            document.getElementById(`quantidade_${index + 1}`).value = produto.quantidade;
            document.getElementById(`multiplicar_${index + 1}`).checked = produto.multiplicar;
            document.getElementById(`designacaoUnitaria_${index + 1}`).value = produto.designacaoUnitaria;
            document.getElementById(`subquantidade_${index + 1}`).value = produto.subquantidade;
            document.getElementById(`designacaoSub_${index + 1}`).value = produto.designacaoSub;
            document.getElementById(`nomeProduto_${index + 1}`).value = produto.nomeProduto;

            // Limpa e gerencia o campo de observação
            let checkboxObs = document.getElementById(`obsCheckbox_${index + 1}`);
            let DivObs = document.getElementById(`observacaoDiv_${index + 1}`);
            let campoObs = document.getElementById(`observacao_${index + 1}`);

            if (produto.observacao) {
                checkboxObs.checked = true;
                DivObs.classList.remove('oculto'); // Mostra o campo se há observação
                campoObs.value = produto.observacao;
            } else {
                checkboxObs.checked = false;
                DivObs.classList.add('oculto'); // Oculta o campo se não há observação
                campoObs.value = ''; // Limpa o valor do campo
            }
        });

        if (resumo.desconto) {
            document.getElementById('valorDesconto').value = resumo.desconto.valor;
            document.getElementById('tipoDesconto').value = resumo.desconto.tipo;
            document.getElementById('descQuant').checked = resumo.desconto.descontoPorQuantidade;
        }

        if (resumo.taxaEntrega) {
            document.getElementById('valorTaxa').value = resumo.taxaEntrega.valor;
            document.getElementById('tipoTaxa').value = resumo.taxaEntrega.tipo;
            document.getElementById('modalidade').value = resumo.taxaEntrega.modalidade;
            document.getElementById('outraModalidade').value = resumo.taxaEntrega.outraModalidade;
            document.getElementById('prazoEntrInicial').value = resumo.taxaEntrega.prazoInicial;
            document.getElementById('prazoEntrFinal').value = resumo.taxaEntrega.prazoFinal;
        }

        atualizarTexto(); // Atualiza o texto gerado
    }
}

function excluirResumo(id) {
    // Exibe uma mensagem de confirmação
    const confirmarExclusao = confirm(`Tem certeza de que deseja excluir o resumo ${id}?`);

    // Se o usuário confirmar, realiza a exclusão
    if (confirmarExclusao) {
        localStorage.removeItem(`resumo_${id}`);
        atualizarListaResumos(); // Atualiza a lista de resumos exibidos
    }
}






function salvarComoPadrao() {
    // Pegar valores dos inputs do cartão
    const acrescimoCartao = document.getElementById("acrescimo-pg-cartao").value;
    const tipoAcrescimoCartao = document.querySelector("#acrescimo-pg-cartao + select").value;
    const descontoCartao = document.getElementById("desconto-pg-cartao").value;
    const tipoDescontoCartao = document.querySelector("#desconto-pg-cartao + select").value;
    const maxParcelasCartao = document.getElementById("max-parcelas-total").value;
    const maxParcelasSemJurosCartao = document.getElementById("max-parcelas-sem-juros").value;
    const valorMinParcelaCartao = document.getElementById("valor-min-parcela").value;

    // Pegar valores dos inputs à vista
    const descontoValorAVista = document.getElementById("desconto-a-vista").value;
    const tipoDescontoAVista = document.getElementById("tipo-desconto-a-vista").value;
    const pixAtivoAVista = document.getElementById("pix-a-vista").checked;
    const boletoAtivoAVista = document.getElementById("boleto-a-vista").checked;
    const dinheiroAtivoAVista = document.getElementById("Dinheiro-a-vista").checked;

    // Salvar no localStorage
    localStorage.setItem('acrescimoCartao', acrescimoCartao);
    localStorage.setItem('tipoAcrescimoCartao', tipoAcrescimoCartao);
    localStorage.setItem('descontoCartao', descontoCartao);
    localStorage.setItem('tipoDescontoCartao', tipoDescontoCartao);
    localStorage.setItem('maxParcelasCartao', maxParcelasCartao);
    localStorage.setItem('maxParcelasSemJurosCartao', maxParcelasSemJurosCartao);
    localStorage.setItem('valorMinParcelaCartao', valorMinParcelaCartao);
    localStorage.setItem('descontoValorAVista', descontoValorAVista);
    localStorage.setItem('tipoDescontoAVista', tipoDescontoAVista);
    localStorage.setItem('pixAtivoAVista', pixAtivoAVista);
    localStorage.setItem('boletoAtivoAVista', boletoAtivoAVista);
    localStorage.setItem('dinheiroAtivoAVista', dinheiroAtivoAVista);
}

function carregarDados() {
    // Carregar os valores do localStorage
    const acrescimoCartao = localStorage.getItem('acrescimoCartao');
    const tipoAcrescimoCartao = localStorage.getItem('tipoAcrescimoCartao');
    const descontoCartao = localStorage.getItem('descontoCartao');
    const tipoDescontoCartao = localStorage.getItem('tipoDescontoCartao');
    const maxParcelasCartao = localStorage.getItem('maxParcelasCartao');
    const maxParcelasSemJurosCartao = localStorage.getItem('maxParcelasSemJurosCartao');
    const valorMinParcelaCartao = localStorage.getItem('valorMinParcelaCartao');
    const descontoValorAVista = localStorage.getItem('descontoValorAVista');
    const tipoDescontoAVista = localStorage.getItem('tipoDescontoAVista');
    const pixAtivoAVista = localStorage.getItem('pixAtivoAVista') === 'true';
    const boletoAtivoAVista = localStorage.getItem('boletoAtivoAVista') === 'true';
    const dinheiroAtivoAVista = localStorage.getItem('dinheiroAtivoAVista') === 'true';

    // Definir os valores nos inputs
    document.getElementById("acrescimo-pg-cartao").value = acrescimoCartao || 0;
    document.querySelector("#acrescimo-pg-cartao + select").value = tipoAcrescimoCartao || "Porcentagem (%)";
    document.getElementById("desconto-pg-cartao").value = descontoCartao || 0;
    document.querySelector("#desconto-pg-cartao + select").value = tipoDescontoCartao || "Porcentagem (%)";
    document.getElementById("max-parcelas-total").value = maxParcelasCartao || 1;
    document.getElementById("max-parcelas-sem-juros").value = maxParcelasSemJurosCartao || 1;
    document.getElementById("valor-min-parcela").value = valorMinParcelaCartao || 1;

    document.getElementById("desconto-a-vista").value = descontoValorAVista || 0;
    document.getElementById("tipo-desconto-a-vista").value = tipoDescontoAVista || "Porcentagem (%)";
    document.getElementById("pix-a-vista").checked = pixAtivoAVista;
    document.getElementById("boleto-a-vista").checked = boletoAtivoAVista;
    document.getElementById("Dinheiro-a-vista").checked = dinheiroAtivoAVista;
}

// Chamar a função carregarDados quando a página for carregada
window.onload = carregarDados;





let contadorDesc = 5; // Inicializa o contador de descontos

// Função para exibir/ocultar o campo de desconto por quantidade
function toggleDescQuant() {
    const descQuantCheckbox = document.getElementById("descQuant");
    const descQuantDiv = document.getElementById("descQuantDiv");

    if (descQuantCheckbox.checked) {
        descQuantDiv.classList.remove("oculto");
    } else {
        descQuantDiv.classList.add("oculto");
    }
}

// Função para adicionar um novo conjunto de campos de desconto com classe dinâmica
function adicionarDescQuant() {
    const descQuantDiv = document.getElementById("descQuantDiv");

    // Cria um novo contêiner com uma classe dinâmica
    const novoDescontoDiv = document.createElement("div");
    novoDescontoDiv.className = `descQuant_${contadorDesc}`;

    // HTML dos novos campos com valores padrão e botão de remoção
    novoDescontoDiv.innerHTML = `
            <label>Quantidade de produtos para aplicar este desconto:</label>
            <input autocomplete="off" type="number" class="quantidade-desc_${contadorDesc}">
            <label>Valor do desconto (R$):</label>
            <input autocomplete="off" type="number" class="valor-desc_${contadorDesc}">
            <button onclick="removerDescQuant(${contadorDesc})">Remover</button>
        `;

    // Incrementa o contador para a próxima chamada
    contadorDesc++;

    // Insere o novo conjunto de campos antes do botão de adicionar mais desconto
    const botaoAdicionar = descQuantDiv.querySelector("button[onclick='adicionarDescQuant()']");
    descQuantDiv.insertBefore(novoDescontoDiv, botaoAdicionar);
    calcularDescontoPorQuantidade();
}

// Função para remover um conjunto de campos de desconto
function removerDescQuant(numero) {
    const elementoParaRemover = document.querySelector(`.descQuant_${numero}`);
    if (elementoParaRemover) {
        elementoParaRemover.remove();
        atualizarTexto();

    }
    calcularDescontoPorQuantidade();
}




const togglePanelButton = document.getElementById('toggle-panel');
const togglePanelHistory = document.getElementById('toggle-panel-history');
const toggleSanelSmartphar = document.getElementById('toggle-panel-smartphar');
const paymentPanel = document.getElementById('payment-panel');
const panelHistory = document.getElementById('panelHistory');
const panelSmartphar = document.getElementById('panel-smartphar');
const closePanelButton = document.getElementById('close-panel');
const closePanelButtonHistory = document.getElementById('close-panel-history');
const closePanelButtonSmartphar = document.getElementById('close-panel-smartphar');

togglePanelHistory.addEventListener('click', () => {
    panelHistory.classList.toggle('open');
});

togglePanelButton.addEventListener('click', () => {
    paymentPanel.classList.toggle('open');
});
toggleSanelSmartphar.addEventListener('click', () => {
    panelSmartphar.classList.toggle('open');
});

closePanelButton.addEventListener('click', () => {
    paymentPanel.classList.remove('open');
});
closePanelButtonHistory.addEventListener('click', () => {
    panelHistory.classList.remove('open');
});
closePanelButtonSmartphar.addEventListener('click', () => {
    panelSmartphar.classList.remove('open');
});


let contador = 1;
document.getElementById("descQuant").addEventListener('change', atualizarTexto);

function atualizarTexto() {

    let tipoResumo = document.getElementById('tipoResumo').value;
    let tituloSection = document.getElementById('titulo-section').innerText;
    let idResumo = document.getElementById('idResumo').value;
    let quantidadeTotalProdutos = 0;
    let textoFinal = '';
    let subtotalGeral = 0; // Inicializa subtotal geral

    // Adiciona tipo e ID do resumo ao texto final
    document.getElementById('titulo-section').innerText = `${tipoResumo}: ${idResumo}`;
    if (tipoResumo && idResumo) {
        textoFinal += (tipoResumo ? tipoResumo : '') + (idResumo ? ': ' + idResumo : '');

    }

    for (let i = 1; i <= contador; i++) {
        if (document.getElementById(`produto_${i}`)) {
            let valorUnitario = parseFloat(document.getElementById(`valorUnitario_${i}`).value) || 0;
            let quantidade = parseFloat(document.getElementById(`quantidade_${i}`).value) || 1;
            let multiplicar = document.getElementById(`multiplicar_${i}`).checked;
            let designacaoUnitaria = document.getElementById(`designacaoUnitaria_${i}`).value || '';
            let subquantidade = parseFloat(document.getElementById(`subquantidade_${i}`).value) || '';
            let designacaoSub = document.getElementById(`designacaoSub_${i}`).value || '';
            let quantidadeParaADose = document.getElementById(`quantidadeParaADose_${i}`).value || '';
            let nQuantDose = document.getElementById(`nQuantDose_${i}`).value;
            let nomeProduto = document.getElementById(`nomeProduto_${i}`).value || '';
            let observacao = document.getElementById(`obsCheckbox_${i}`).checked ? document.getElementById(`observacao_${i}`).value : '';

            const designacaoSelect = document.getElementById(`designacaoSub_${i}`);
            const doseFields = document.getElementById(`doseFields_${i}`);

            // Verifica se a opção selecionada é "doses"
            if (designacaoSelect.value === "doses") {
                doseFields.style.display = "block"; // Exibe os campos

            } else {
                doseFields.style.display = "none"; // Oculta os campos
            }


            //opções de obs
            const simboloRadioButtons = document.getElementsByName('simbolo');

            function getSimboloSelecionado() {
                for (const radioButton of simboloRadioButtons) {
                    if (radioButton.checked) {
                        return radioButton.value;
                    }
                }
                return '*'; // Padrão
            }


            document.getElementById(`observacao_${i}`).addEventListener('input', function () {
                const simbolo = getSimboloSelecionado();
                const linhas = this.value.split('\n');
                this.value = linhas.map(linha => linha.startsWith(`${simbolo}`) ? linha : `${simbolo} ${linha}`).join('\n');
            });

            // Calcula o subtotal
            let subtotal = multiplicar ? valorUnitario * quantidade : valorUnitario;
            document.getElementById(`subtotal_${i}`).textContent = `R$ ${subtotal.toFixed(2)}`;
            quantidadeTotalProdutos += quantidade;


            // Monta a linha do produto
            if (subtotal > 0 && (nomeProduto || (valorUnitario > 0 && quantidade > 0))) {
                let linhaProduto = `\n\n\n*+ R$ ${subtotal.toFixed(2)}* | `;

                if (quantidade && designacaoUnitaria) {
                    linhaProduto += `${quantidade} ${designacaoUnitaria}`;
                }

                if (valorUnitario > 0 && quantidade > 1 && multiplicar) {
                    linhaProduto += ` (R$ ${valorUnitario.toFixed(2)} cada)`;
                }

                if (subquantidade && designacaoSub) {
                    linhaProduto += ` X ${subquantidade} ${designacaoSub}`;

                }

                if (nomeProduto) {
                    linhaProduto += ` - ${nomeProduto}`;
                }

                if (designacaoSelect.value === "doses") {
                    linhaProduto += ` (1 dose = ${nQuantDose} ${quantidadeParaADose})`;

                }


                textoFinal += linhaProduto;

                // Adiciona observação se houver
                if (observacao) {
                    textoFinal += `\n${observacao}`;
                }


                // Adiciona ao subtotal geral
                subtotalGeral += subtotal;
            }
        }
    }

    let descQuant = document.getElementById(`descQuant`).checked;
    if (descQuant) {


        // Calcula e aplica o desconto por quantidade
        let descontoPorQuantidade = calcularDescontoPorQuantidade(quantidadeTotalProdutos);
        subtotalGeral -= descontoPorQuantidade;


        // Adiciona o valor do desconto ao texto final se aplicável
        if (descontoPorQuantidade > 0) {
            textoFinal += `\n\n\n*- R$ ${descontoPorQuantidade.toFixed(2)}* desconto por quantidade`;
        }
    }

    // Captura os valores dos inputs do envio
    const valorTaxa = parseFloat(document.getElementById("valorTaxa").value) || 0;
    const tipoTaxa = document.getElementById("tipoTaxa").value;
    const modalidade = document.getElementById("modalidade").value;
    const outraModalidade = document.getElementById("outraModalidade").value;
    const prazoEntrInicial = parseInt(document.getElementById("prazoEntrInicial").value) || 0;
    const prazoEntrFinal = parseInt(document.getElementById("prazoEntrFinal").value) || 0;

    // Calcula o valor final da taxa de entrega com base no tipo selecionado
    let valorFinalTaxa;
    if (tipoTaxa === "percentual") {
        valorFinalTaxa = (subtotalGeral * valorTaxa) / 100;
    } else {
        valorFinalTaxa = valorTaxa;
    }

    // Determina o texto da modalidade de entrega
    let modalidadeTexto = modalidade !== "selecione" ? modalidade : outraModalidade;
    if (!modalidadeTexto) modalidadeTexto = "Entrega";

    // Exibe o valor final da taxa e detalhes no console ou insere no HTML
    console.log(`Valor da Taxa de Entrega: R$ ${valorFinalTaxa.toFixed(2)}`);
    console.log(`Modalidade de Entrega: ${modalidadeTexto}`);
    console.log(`Prazo de Entrega: ${prazoEntrInicial} a ${prazoEntrFinal} dias úteis`);

    if (valorFinalTaxa <= 0 && modalidade !== "selecione") {
        textoFinal += `\n\n\n*FRETE GRÁTIS* ${modalidadeTexto}`
        if (prazoEntrFinal > 0) {
            textoFinal += ` - Prazo de entrega: ${prazoEntrInicial} a ${prazoEntrFinal} dias úteis`
        }
    }

    if (valorFinalTaxa > 0) {
        textoFinal += `\n\n\n*+ R$ ${valorFinalTaxa.toFixed(2)}* ${modalidadeTexto}`
        if (prazoEntrFinal > 0) {
            textoFinal += ` - Prazo de entrega: ${prazoEntrInicial} a ${prazoEntrFinal} dias úteis`
        }
    }



    // Calcula e aplica o desconto
    let valorDesconto = parseFloat(document.getElementById('valorDesconto').value) || 0;
    let tipoDesconto = document.getElementById('tipoDesconto').value;

    if (valorDesconto > 0) {
        let descontoTexto = '';
        if (tipoDesconto === 'percentual') {
            const descontoPercentual = (subtotalGeral * valorDesconto) / 100; // Calcula desconto percentual
            subtotalGeral -= descontoPercentual; // Aplica o desconto
            descontoTexto = `*- R$ ${descontoPercentual.toFixed(2)}* Desconto (${valorDesconto}%)`;
        } else { // Se for valor fixo
            subtotalGeral -= valorDesconto; // Aplica o desconto
            descontoTexto = `*- R$ ${valorDesconto.toFixed(2)}* Desconto (R$)`;
        }
        textoFinal += `\n\n\n${descontoTexto}`; // Adiciona texto do desconto
    }

    if (valorFinalTaxa > 0) {
        subtotalGeral += valorFinalTaxa;
    }


    // Pegar valores dos inputs do cartao
    const checkboxCartao = document.getElementById("cartao-credito").checked;
    const acrescimoCartao = parseFloat(document.getElementById("acrescimo-pg-cartao").value) || 0;
    const tipoAcrescimoCartao = document.querySelector("#acrescimo-pg-cartao + select").value;
    const descontoCartao = parseFloat(document.getElementById("desconto-pg-cartao").value) || 0;
    const tipoDescontoCartao = document.querySelector("#desconto-pg-cartao + select").value;
    const maxParcelasCartao = parseInt(document.getElementById("max-parcelas-total").value) || 1;
    const maxParcelasSemJurosCartao = parseInt(document.getElementById("max-parcelas-sem-juros").value) || 1;
    const valorMinParcelaCartao = parseFloat(document.getElementById("valor-min-parcela").value) || 0;

    // Calcular acréscimo e desconto no valor total
    let valorFinalCartao = subtotalGeral;
    let textoAcrescimoCartao = '';
    let textoDescontoCartao = '';

    if (checkboxCartao) {
        // Aplicar acréscimo
        if (tipoAcrescimoCartao === "Porcentagem (%)") {
            textoAcrescimoCartao = `(Acrescimo de ${acrescimoCartao}%)`
            valorFinalCartao += (valorFinalCartao * acrescimoCartao) / 100;

        } else if (tipoAcrescimoCartao === "Valor Fixo (R$)") {
            textoAcrescimoCartao = `(Acrescimo de R$ ${acrescimoCartao})`
            valorFinalCartao += acrescimoCartao;
        }

        // Aplicar desconto
        if (tipoDescontoCartao === "Porcentagem (%)") {
            textoDescontoCartao = `(Desconto de ${descontoCartao}%)`
            valorFinalCartao -= (valorFinalCartao * descontoCartao) / 100;
        } else if (tipoDescontoCartao === "Valor Fixo (R$)") {
            textoDescontoCartao = `(Desconto de R$ ${descontoCartao})`
            valorFinalCartao -= descontoCartao;
        }
    }

    // Calcular parcelamento sem juros respeitando o valor mínimo da parcela
    let parcelasSemJuros = maxParcelasSemJurosCartao;
    let valorParcelaSemJurosCartao = valorFinalCartao / parcelasSemJuros;

    while (parcelasSemJuros > 1 && valorParcelaSemJurosCartao < valorMinParcelaCartao) {
        parcelasSemJuros--;
        valorParcelaSemJurosCartao = valorFinalCartao / parcelasSemJuros;
    }

    // Calcular parcelamento total respeitando o valor mínimo da parcela
    let parcelasComJuros = maxParcelasCartao;
    let valorParcelaComJurosCartao = valorFinalCartao / parcelasComJuros;

    while (parcelasComJuros > 1 && valorParcelaComJurosCartao < valorMinParcelaCartao) {
        parcelasComJuros--;
        valorParcelaComJurosCartao = valorFinalCartao / parcelasComJuros;
    }



    // Armazenar os valores calculados
    const resultadosCartao = {
        valorFinalCartao: valorFinalCartao.toFixed(2),
        valorParcelaComJurosCartao: valorParcelaComJurosCartao.toFixed(2),
        parcelasComJuros: parcelasComJuros,
        valorParcelaSemJurosCartao: valorParcelaSemJurosCartao.toFixed(2),
        parcelasSemJuros: parcelasSemJuros
    };

    console.log(resultadosCartao);
    let textoCartao = '';

    let txtParcelasComJuros = '';
    if (parcelasComJuros > parcelasSemJuros && parcelasSemJuros > 1) {
        txtParcelasComJuros += `ou até ${parcelasComJuros}x com juros`;
    } else if (parcelasComJuros > 1 && parcelasSemJuros == 1) {
        txtParcelasComJuros = `Parcele em até ${parcelasComJuros}x com juros`;
    } else if (parcelasComJuros = parcelasSemJuros && parcelasSemJuros > 1) {
        txtParcelasComJuros = '';
    } else {
        txtParcelasComJuros = `R$ ${valorFinalCartao.toFixed(2)}`;
    }

    let txtParcelasSemJuros = '';
    if (parcelasSemJuros > 1) {
        txtParcelasSemJuros += `Parcele em até ${parcelasSemJuros}x de R$ ${valorParcelaSemJurosCartao.toFixed(2)} sem juros`;
    }


    if (checkboxCartao && acrescimoCartao > 0 && descontoCartao <= 0) {
        textoCartao += `💳 Cartão de Crédito - ${textoAcrescimoCartao} ${txtParcelasSemJuros} ${txtParcelasComJuros}`;
    } else if (checkboxCartao && descontoCartao > 0 && acrescimoCartao <= 0) {
        textoCartao += `💳 Cartão de Crédito - ${textoDescontoCartao} ${txtParcelasSemJuros} ${txtParcelasComJuros}`;
    } else if (checkboxCartao) {
        textoCartao += `💳 Cartão de Crédito - ${txtParcelasSemJuros} ${txtParcelasComJuros}`;
    } else {
        textoCartao += '';
    }


    // Captura os valores dos checkboxes pagamento a vista
    const pixAtivoAVista = document.getElementById("pix-a-vista").checked;
    const boletoAtivoAVista = document.getElementById("boleto-a-vista").checked;
    const dinheiroAtivoAVista = document.getElementById("Dinheiro-a-vista").checked;

    // Captura o valor e tipo de desconto
    const descontoValorAVista = parseFloat(document.getElementById("desconto-a-vista").value) || 0;
    const tipoDescontoAVista = document.getElementById("tipo-desconto-a-vista").value;

    // Cálculo do valor com desconto
    let valorFinalAVista = subtotalGeral;
    let textoDescontoAvista = '';

    if (descontoValorAVista > 0) {
        if (tipoDescontoAVista === "Porcentagem (%)") {
            textoDescontoAvista += `com desconto de ${descontoValorAVista}%`
            valorFinalAVista -= ((subtotalGeral - valorFinalTaxa) * descontoValorAVista) / 100;
        } else if (tipoDescontoAVista === "Valor Fixo (R$)") {
            textoDescontoAvista += `com desconto de R$ ${descontoValorAVista}`
            valorFinalAVista -= descontoValorAVista;

        }
    }

    // Armazenar as opções ativas em uma lista
    let opcoesAtivas = [];
    if (pixAtivoAVista) opcoesAtivas.push("Pix");
    if (boletoAtivoAVista) opcoesAtivas.push("boleto");
    if (dinheiroAtivoAVista) opcoesAtivas.push("dinheiro");

    // Criar a frase de acordo com as opções ativas
    let textoAVista = "";
    if (opcoesAtivas.length > 0) {
        if (opcoesAtivas.length === 1) {
            textoAVista = `💠 A vista - *R$ ${valorFinalAVista.toFixed(2)}* no ${opcoesAtivas[0]} ${textoDescontoAvista}`;
        } else if (opcoesAtivas.length === 2) {
            textoAVista = `💠 A vista - *R$ ${valorFinalAVista.toFixed(2)}* no ${opcoesAtivas[0]} ou ${opcoesAtivas[1]} ${textoDescontoAvista}`;
        } else if (opcoesAtivas.length === 3) {
            textoAVista = `💠 A vista - *R$ ${valorFinalAVista.toFixed(2)}* no ${opcoesAtivas[0]}, ${opcoesAtivas[1]} ou ${opcoesAtivas[2]} ${textoDescontoAvista}`;
        }
    }


    // Armazenar os valores para verificar quais opções estão ativas e o valor final
    const resultadosAVista = {
        pixAtivoAVista,
        boletoAtivoAVista,
        dinheiroAtivoAVista,
        valorFinalAVista: valorFinalAVista.toFixed(2)
    };

    console.log(resultadosAVista);



    // Adiciona o subtotal geral apenas na saída
    if (subtotalGeral > 0) {
        textoFinal += `\n\n\n-----------------\n\n*= R$ ${subtotalGeral.toFixed(2)} Total do ${tipoResumo}*\n\n`;
    }

    if (checkboxCartao) {
        textoFinal += `Formas de pagamento:\n\n`;
    }

    if (checkboxCartao) {
        textoFinal += `${textoCartao}\n\n`
    }

    if (descontoValorAVista >= 0) {
        if (pixAtivoAVista || boletoAtivoAVista || dinheiroAtivoAVista) {
            textoFinal += `${textoAVista}`
        }
    }



    document.getElementById('textoFinal').value = textoFinal.trim();
    autoResize();
    textarea.addEventListener("input", autoResize);
}

// Função para calcular o desconto total com base nas regras de quantidade
function calcularDescontoPorQuantidade(quantidadeTotal) {
    let valorDescQuantAplicado = 0;
    const descQuantDiv = document.getElementById("descQuantDiv");

    // Loop através de cada conjunto de desconto e aplica o maior aplicável
    for (let i = 1; i < contadorDesc; i++) {
        let quantidadeDesc = parseFloat(document.querySelector(`.quantidade-desc_${i}`).value) || 0;
        let valorDesc = parseFloat(document.querySelector(`.valor-desc_${i}`).value) || 0;

        if (quantidadeTotal >= quantidadeDesc) {

            valorDescQuantAplicado = Math.max(valorDescQuantAplicado, valorDesc);

        }
    }

    return valorDescQuantAplicado;
    atualizarTexto();
}




function adicionarProduto() {
    contador++;
    const novoProduto = document.createElement('div');
    novoProduto.className = 'produto';
    novoProduto.tabIndex = '0';
    novoProduto.id = `produto_${contador}`;
    novoProduto.innerHTML = `
                <h3 class="input-group quebra-linha" style="margin: 0; font-size: 12pt;">Produto ${contador}</h3>
                <div class="input-container" style="flex-grow: 0;">
                    <div style="max-width: 5rem;" class="input-group">
                        <label>Valor (R$):</label>
                        <input autocomplete="off" type="number" id="valorUnitario_${contador}" oninput="atualizarTexto()" step="0.01">
                    </div>
                    <div class="input-group" style="flex-direction: row; line-height: normal;">
                        <label style="display: flex; align-items: center;"><input autocomplete="off" type="checkbox"
                                id="multiplicar_${contador}" checked onchange="atualizarTexto()">
                            Multiplicar pela quantidade</label>
                    </div>
                </div>
                <div class="input-container">
                    <div class="input-group" style="max-width: 4rem;">
                        <label>Quantidade:</label>
                        <input autocomplete="off" type="number" id="quantidade_${contador}" min="1" value="1"
                            oninput="atualizarTexto()">
                    </div>
                    <div class="input-group">
                        <label>Descrição Unitária:</label>
                        <select autocomplete="off" id="designacaoUnitaria_${contador}" onchange="atualizarTexto()">
                            <option value="un">un</option>
                            <option value="cx">cx</option>
                            <option value="kit">kit</option>
                            <option value="fr">fr</option>
                            <option value="pote">pote</option>
                            <option value="pct">pct</option>
                            <option value="bisnaga">bisnaga</option>
                            <option value="kg">kg</option>
                            <option value="g">g</option>
                            <option value="mg">mg</option>
                            <option value="L">L</option>
                            <option value="ml">ml</option>
                            <option value="ton">ton</option>
                            <option value="cp">cp</option>
                            <option value="dose">dose</option>
                            <option value="pç">pç</option>
                            <option value="fardo">fardo</option>
                            <option value="palet">palet</option>
                            <option value="sache">sache</option>
                            <option value="mão de obra">mão de obra</option>
                        </select>
                    </div>
                </div>
                <div class="input-container">
                    <div class="input-group" style="max-width: 5rem;">
                        <label>Subquantidades:</label>
                        <input autocomplete="off" type="number" id="subquantidade_${contador}" oninput="atualizarTexto()">
                    </div>

                    <div class="input-group">
                        <label>Desc. Unit. Subquantidades:</label>
                        <select autocomplete="off" id="designacaoSub_${contador}" onchange="atualizarTexto()">
                            <option value="">Selecione</option>
                            <option value="un">un</option>
                            <option value="cx">cx</option>
                            <option value="kits">kit</option>
                            <option value="fr">fr</option>
                            <option value="potes">pote</option>
                            <option value="pct">pct</option>
                            <option value="ml">ml</option>
                            <option value="kg">kg</option>
                            <option value="g">g</option>
                            <option value="mg">mg</option>
                            <option value="L">L</option>
                            <option value="ml">ml</option>
                            <option value="ton">ton</option>
                            <option value="cp">cp</option>
                            <option value="cápsulas">cápsulas</option>
                            <option value="doses">doses</option>
                            <option value="pçs">pç</option>
                            <option value="fardos">fardos</option>
                            <option value="saches">saches</option>
                            <option value="palets">palet</option>
                        </select>
                    </div>
                </div>


                <div id="doseFields_${contador}" class="oculto input-group" style="display: none;">
                    <label>1 dose = </label>
                    <input autocomplete="off" style="max-width: 4rem;" type="text" value="2" id="nQuantDose_${contador}"
                        oninput="atualizarTexto()">
                    <select autocomplete="off" id="quantidadeParaADose_${contador}" onchange="atualizarTexto()">
                        <option value="cápsulas">cápsulas</option>
                        <option value="cápsula">cápsula</option>
                        <option value="dosador">dosador</option>
                        <option value="dosadores">dosadores</option>
                        <option value="grama">grama</option>
                        <option value="gramas">gramas</option>
                        <option value="pump">pump</option>
                        <option value="gota">gota</option>
                        <option value="gotas">gotas</option>
                    </select>
                </div>


                <div class="input-group">
                    <input placeholder="Nome do Produto"  autocomplete="off" style="width: 100%;" type="text" id="nomeProduto_${contador}" oninput="atualizarTexto()">
                </div>


                <label style="display: flex;align-items: center; flex-basis: 100%;"><input autocomplete="off" type="checkbox"
                        id="obsCheckbox_${contador}" onchange="toggleObservacao(${contador})">Observações</label>


                <div id="observacaoDiv_${contador}" class="oculto">
                    <label style="display: inline;">Estilo da observação:</label>
                    <input autocomplete="off" type="radio" id="simboloMaior" name="simbolo" value=">">
                    <label style="display: inline;" for="simboloMaior">Citação</label>
                    <input autocomplete="off" type="radio" id="simboloAsterisco" name="simbolo" value="*" checked>
                    <label style="display: inline;" for="simboloAsterisco">Lista</label><br>
                    <label>Observações:</label>
                    <textarea style="width: 100%; height: 7rem;" autocomplete="off" id="observacao_${contador}"
                        oninput="atualizarTexto()"></textarea>
                </div>
                <div class="input-group quebra-linha"
                    style="flex-direction: row;align-items: center;">
                    <p><strong>Subtotal:</strong> <span id="subtotal_${contador}">R$ 0,00</span></p>
                    <button class="outline-btn" onclick="removerProduto(${contador})">Remover Produto</button>
                </div>
            `;
    document.getElementById('produtos').appendChild(novoProduto);
    atualizarTexto(); // Atualiza o texto após adicionar novo produto
}

function removerProduto(num) {
    const produto = document.getElementById(`produto_${num}`);
    if (produto) {
        produto.remove(); // Remove o produto do DOM
        atualizarTexto(); // Atualiza o texto após remover o produto
    }
}

function toggleObservacao(num) {
    const observacaoDiv = document.getElementById(`observacaoDiv_${num}`);
    observacaoDiv.classList.toggle('oculto');
    atualizarTexto(); // Atualiza o texto após alterar visibilidade da observação
}









function carregarOrcamentoSmartphar() {
    const texto = document.getElementById("orcamento-smartphar").value;
    const linhas = texto.split("\n");
    const produtos = [];
    let idOrcamento = null;

    for (let i = 0; i < linhas.length; i++) {
        const linha = linhas[i];

        // Ignorar linhas com "----------------------------------------"
        if (linha === "----------------------------------------") {
            continue;
        }

        // Encontrar o número da Req como id do orçamento
        if (linha.startsWith("Req:")) {
            const partes = linha.split(" ");
            idOrcamento = partes[1]; // Usar o número da Req como ID do orçamento
            continue;
        }

        // Verificar a linha que define o tipo da fórmula, quantidade e subquantidade
        if (linha.startsWith("Fórmula -")) {
            const formulaRegex = /Fórmula - (.*?): (\d+) UN X (\d+)([A-Za-z]*)/;
            const match = linha.match(formulaRegex);
            if (match) {
                const tipoFormula = match[1] ? match[1] : "Fórmula Genérica"; // Se não houver tipo, atribui um nome genérico
                const quantidade = parseInt(match[2]);
                const subquantidade = parseInt(match[3]);
                let designacaoUnitaria;

                // Definir a designação unitária com base no tipo de fórmula
                if (tipoFormula.trim() === "") { // Se não especificado, define como "fr"
                    designacaoUnitaria = "fr";
                } else if (["Capsulas", "Capsulas Semi - Acabadas", "Esmalte", "Florais", "Loções", "Serum", "Shampoos", "Xarope"].includes(tipoFormula)) {
                    designacaoUnitaria = "fr";
                } else if (["Cremes", "Pomadas"].includes(tipoFormula)) {
                    designacaoUnitaria = "bisnaga";
                } else if (["Outros", "Unidades"].includes(tipoFormula)) {
                    designacaoUnitaria = "un";
                } else if (tipoFormula === "Saches") {
                    designacaoUnitaria = "cx";
                } else {
                    designacaoUnitaria = "un"; // Padrão se não se encaixar em nenhuma categoria
                }

                // Extrair a designação das subquantidades
                const subquantidadeTexto = linha.slice(-3); // Pega os últimos 3 caracteres
                let designacaoSub;

                // Definir a designação das subquantidades
                switch (subquantidadeTexto) {
                    case "CAP":
                        designacaoSub = "cápsulas";
                        break;
                    case "G  ": // Certifique-se de que os espaços estão corretos
                        designacaoSub = "g";
                        break;
                    case "ML ": // Verifique o espaço ao final
                        designacaoSub = "ml";
                        break;
                    case "L  ": // Verifique o espaço ao final
                        designacaoSub = "L";
                        break;
                    case "KG ": // Verifique o espaço ao final
                        designacaoSub = "kg";
                        break;
                    case "UN ": // Verifique o espaço ao final
                        designacaoSub = "un";
                        break;
                    default:
                        designacaoSub = ""; // Se não houver correspondência
                        break;
                }

                produtos.push({
                    tipoFormula,
                    quantidade,
                    subquantidade,
                    designacaoUnitaria,
                    designacaoSub, // Adiciona a designação das subquantidades
                    subtotal: null // Será preenchido na linha "Valor"
                });
            }
        }



        // Verificar a linha que define o subtotal do produto
        if (linha.startsWith("Valor:")) {
            const valorRegex = /Valor: R\$\s*([\d,]+)/;
            const match = linha.match(valorRegex);
            if (match && produtos.length > 0) {
                // Substituir vírgula por ponto para conversão em número
                const subtotal = parseFloat(match[1].replace(",", "."));
                produtos[produtos.length - 1].subtotal = subtotal;
            }
        }
    }

    // Retorna os dados extraídos
    return { idOrcamento, produtos };

}

function carregarOrcamentoSmartpharParaCampos() {
    // Extrair dados do orçamento do campo de texto
    const resultadoOrcamento = carregarOrcamentoSmartphar();
    if (!resultadoOrcamento || !resultadoOrcamento.produtos.length) return; // Verifica se há dados

    // Definir o tipo de orçamento e o ID
    document.getElementById('tipoResumo').value = 'Orçamento'; // Defina o tipo conforme necessário
    document.getElementById('idResumo').value = resultadoOrcamento.idOrcamento;
    document.getElementById('titulo-section').innerText = `Orçamento: ${resultadoOrcamento.idOrcamento}`;

    // Limpar produtos existentes
    let contador = produtos.length; // Obtenha a quantidade atual de produtos
    while (contador > 1) {
        removerProduto(contador--);
    }

    // Preencher os campos com os dados dos produtos
    resultadoOrcamento.produtos.forEach((produto, index) => {
        if (index > 0) adicionarProduto(); // Adiciona um novo campo de produto se necessário

        document.getElementById(`valorUnitario_${index + 1}`).value = produto.subtotal; // Preencher subtotal
        document.getElementById(`quantidade_${index + 1}`).value = produto.quantidade;
        document.getElementById(`multiplicar_${index + 1}`).checked = false; // Checkbox desmarcado, pois subtotal já foi fornecido
        document.getElementById(`designacaoUnitaria_${index + 1}`).value = produto.designacaoUnitaria;
        document.getElementById(`subquantidade_${index + 1}`).value = produto.subquantidade;
        document.getElementById(`designacaoSub_${index + 1}`).value = produto.designacaoSub; // Ajuste conforme necessário
        console.log(produto.designacaoSub);

        // Limpa e gerencia o campo de observação (sem observação no texto importado)
        let checkboxObs = document.getElementById(`obsCheckbox_${index + 1}`);
        let DivObs = document.getElementById(`observacaoDiv_${index + 1}`);
        let campoObs = document.getElementById(`observacao_${index + 1}`);
        checkboxObs.checked = false;
        DivObs.classList.add('oculto');
        campoObs.value = ''; // Limpa o valor do campo
    });

    // Atualiza o texto gerado
    atualizarTexto();
}



function compartilharWhatsApp() {
    // Codifica a mensagem para ser compatível com URLs
    const compLink = document.getElementById('textoFinal').value;
    const mensagemCodificada = encodeURIComponent(compLink);

    // Detecta se o usuário está em um dispositivo móvel
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);

    // Define o link apropriado com base no dispositivo
    const linkWhatsApp = isMobile
        ? `https://api.whatsapp.com/send/?text=${mensagemCodificada}`
        : `https://web.whatsapp.com/send/?text=${mensagemCodificada}`;

    // Abre o link em uma nova aba/janela
    window.open(linkWhatsApp, '_blank');
}

async function copiarTexto() {
    // Obtém o conteúdo do textarea
    const elementoTexto = document.getElementById("textoFinal").value;

    try {
        // Usa a API de Clipboard para copiar o texto
        await navigator.clipboard.writeText(elementoTexto);

        // Muda o texto do botão para "Copiado!"
        const button = document.getElementById("copyButton");
        button.textContent = "Copiado ✔";

        // Restaura o texto original após 2 segundos
        setTimeout(() => {
            button.textContent = "Copiar Texto";
        }, 2000);
    } catch (err) {
        console.error("Erro ao copiar o texto: ", err);
    }
}